package thread3;
class withdrawalTask implements Runnable{
	private Customer customer;
	withdrawalTask(Customer customer){
		this.customer=customer;
		
	}
	@Override
	public void run() {
		customer.getAccount().withdraw(2500);
	}
}

public class MultiThreadedBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer = new Customer("Renuka","Katneshwarkar");
		Account account = new Account(1000);
		customer.setAccount(account);
		
		System.out.println("Intial balance"+customer.getAccount().getBalance());
		
		account.deposite(5000);
		System.out.println("Balance after deposite:"+account.getBalance());
		
		withdrawalTask task =new withdrawalTask(customer);
		Thread t1 = new Thread(task);
		Thread t2 = new Thread(task);
		Thread t3 = new Thread(task);
		Thread t4 = new Thread(task);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
		
	}

}
//wait notify and notifyAll