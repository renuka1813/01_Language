package thread3;

public class SingleThreadedBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer = new Customer("Renuka","Katneshwarkar");
		Account account = new Account(1000);
		customer.setAccount(account);
		
		System.out.println("Intial balance"+customer.getAccount().getBalance());
		
		account.deposite(5000);
		System.out.println("Balance after deposite:"+customer.getAccount().getBalance());
		
		account.withdraw(1500);
		account.withdraw(4000);
		account.withdraw(1500);
	}

}
