package thread1;

public class Test3 implements Runnable {
	public void run() {
		System.out.println("Name of Thread: "+Thread.currentThread().getName());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test3 obj = new Test3();
		//obj.start();
		Thread t1 = new Thread();//worker thread
		
	}

}
