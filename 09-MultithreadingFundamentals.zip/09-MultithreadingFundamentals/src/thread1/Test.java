package thread1;

public class Test {
	public void run() {
		System.out.println("Name of Thread: "+Thread.currentThread().getName());
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Test().run();
	}

}
