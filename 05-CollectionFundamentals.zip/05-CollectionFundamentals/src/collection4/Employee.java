package collection4;

import java.util.ArrayList;
import java.util.Iterator;

public class Employee {
	private int empId;
	private String empName;
	private String address;
	private double sal;
	public Employee(int empId, String empName, String address, double sal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.address = address;
		this.sal = sal;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
	
	public void search(int empId, String empName, ArrayList<Employee> list) {
		Iterator<Employee> itr = list.iterator();
		while(itr.hasNext()) {
			//if(Employee.empId == empId && employee.empName == empName)
				System.out.println();
				
		}
	}
}
