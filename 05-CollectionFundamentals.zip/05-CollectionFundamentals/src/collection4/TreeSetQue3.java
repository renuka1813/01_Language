/*3. Create Collection called TreeSet which can store String objects. The
Collection should have the following capabilities:
a. Reverse the elements of the Collection
b. Iterate the elements of the TreeSet
c. Checked if a particular element exists or not*/

package collection4;


import java.util.Iterator;
import java.util.TreeSet;



public class TreeSetQue3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> set = new TreeSet<String>();
		set.add("Java");
		set.add("DS");
		set.add("DB");
		set.add("WPT");
		
		//System.out.println(set.descendingSet());
		Iterator<String> itr = set.iterator();
		while(itr.hasNext()) {
			String str = itr.next();
			System.out.println(str);
		}	
		boolean exists = set.contains("Java");
	    System.out.println("Java exists in TreeSet ? : " + exists);
	}

}
