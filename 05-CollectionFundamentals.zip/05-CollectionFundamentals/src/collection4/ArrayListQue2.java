/*2. Create an ArrayList which will be able to store only numbers like
int,float,double,etc, but not any other data type.*/

package collection4;

import java.util.ArrayList;

public class ArrayListQue2<E> extends ArrayList<E> {
	@Override
	public boolean add(E e) {
		if (e instanceof Integer || e instanceof Float || e instanceof Double) {
			super.add(e);
			return true;
		} else {
			throw new ClassCastException("Only Integer, Float, and Double are supported.");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Object> list = new ArrayListQue2<>();
		try {
			list.add(15);
			list.add(2.7F);
			list.add(12.87876D);
			list.add(23);
			list.add("xyz");
		} catch (Exception e) {
			System.out.println("enter valid input");
		}
		System.out.println(list);
	}

}
