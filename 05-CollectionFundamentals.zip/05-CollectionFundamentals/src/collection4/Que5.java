package collection4;

//Write a program to store a group of employee names into a HashSet,
//retrieve the elements one by one using an Iterator

import java.util.HashSet;
import java.util.Iterator;
public class Que5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       HashSet<String> h1=new HashSet<>();
       h1.add("Omkar");
       h1.add("Renu");
       h1.add("Kulna");
       h1.add("Siyal");
       
       
       Iterator<String>itr=h1.iterator();
       while(itr.hasNext()) {
       System.out.println("Employees are: "+itr.next());
       }
	}

}