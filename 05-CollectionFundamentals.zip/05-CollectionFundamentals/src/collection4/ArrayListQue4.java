/*4. Create an ArrayList of Employee (id, name, address, sal) objects and
search for Employee object based on id number and name.*/

package collection4;

import java.util.ArrayList;

public class ArrayListQue4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee(1,"Renuka", "xyz",10000);
		Employee e1 = new Employee(2,"Piyush", "abc",20000);
		Employee e2 = new Employee(3,"Shubham", "qwer",30000);
		Employee e3 = new Employee(1,"Renuka", "xyz",10000);
		
		ArrayList<Employee> list  = new ArrayList<>(); 
		list.add(e);
		list.add(e1);
		list.add(e2);
		list.add(e3);
		
		

	}

}
