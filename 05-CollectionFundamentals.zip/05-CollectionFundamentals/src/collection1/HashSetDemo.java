package collection1;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> hs = new HashSet<String>();
		hs.add("MorningStar");
		hs.add("JPM");
		hs.add("TCS");
		hs.add("Wipro");
		hs.add("TCS");
		
		//System.out.println(hs);
		Iterator<String> itr = hs. iterator();
		while(itr.hasNext()) {
			String str = itr.next();
			System.out.println("Company Name: "+str+", Length: "+str.length());
		}
	}

}
