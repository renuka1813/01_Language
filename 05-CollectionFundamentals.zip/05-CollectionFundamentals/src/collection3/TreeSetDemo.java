package collection3;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student(100, "Renuka", 90);
		Student student2 = new Student(100, "Omkar", 90);
		Student student3 = new Student(100, "Omkar", 90);
		
		System.out.println("student1 hashcode: "+student1.hashCode());
		System.out.println("student1 hashcode: "+student2.hashCode());
		
		
		TreeSet<Student> set = new TreeSet<>(); // diamond -- java 1.7
		set.add(student1);
		set.add(student2);
		set.add(student3);
		
		System.out.println(set);

	}

}
