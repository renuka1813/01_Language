package Lab0;

import java.util.Scanner;

public class SumOfDigit {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter a number ");
		int num= sc.nextInt();
		int sum=0;
		int input=num;
		while(input != 0) {
			int lastdigit = input % 10;
			sum += lastdigit;
			input /= 10;
		}
		System.out.printf("Sum of digit of number %d is %d", num, sum);
		sc.close();
		
	}

}
