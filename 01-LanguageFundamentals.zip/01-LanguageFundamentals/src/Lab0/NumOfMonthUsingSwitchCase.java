package Lab0;

public class NumOfMonthUsingSwitchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
