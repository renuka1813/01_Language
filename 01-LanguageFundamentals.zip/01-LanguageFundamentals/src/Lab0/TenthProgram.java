package Lab0;

import java.util.Scanner;

public class TenthProgram {

	public static void main(String[] args) {
		double basic,da,hra,gross;
		System.out.println("Enter Basic salary of the employee\n");
		Scanner obj1=new Scanner(System.in);
		basic=obj1.nextDouble();
		if(basic <=15000)
		{
			hra=20*basic/100;
			da=70*basic/100;
			gross= basic+da+hra;
			System.out.println("The D.A of the basic salary of the employee is:" +da);
			System.out.println("The H.R.A of the basic salary of the employee is:" +hra);
			System.out.println("The Gross salary of the employee is:" +gross);
		}
		else if(basic <=30000) {
			hra=35*basic/100;
			da=80*basic/100;
	     	gross= basic+da+hra;
			System.out.println("The D.A of the basic salary of the employee is:" +da);
			System.out.println("The H.R.A of the basic salary of the employee is:" +hra);
			System.out.println("The Gross salary of the employee is:" +gross);
		}
		else(basic >30000)
		da=80*basic/100;
		hra=20*basic/100;
		gross= basic+da+hra;
		System.out.println("The D.A of the basic salary of the employee is:" +da);
		System.out.println("The H.R.A of the basic salary of the employee is:" +hra);
		System.out.println("The Gross salary of the employee is:" +gross);
		
	}

}
