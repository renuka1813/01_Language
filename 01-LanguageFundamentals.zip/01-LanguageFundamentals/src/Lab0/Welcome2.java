package Lab0;

public class Welcome2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcom to java Programming!");

	}

}
