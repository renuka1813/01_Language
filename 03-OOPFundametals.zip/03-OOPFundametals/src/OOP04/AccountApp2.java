package OOP04;

public class AccountApp2 {
	public static void main(String[] args) {
		Account acc = null;
		if(Math.random() > 10) {
			acc = new Saving(101010,"Renuka",50000,4.5);		
	
		}
		else {
			acc = new Current(110011, "omkar",25000, 50000);
		}
		acc.showAccount();
	}

}
