package OOP06;
public class Vehicle
{
	private int reg_no;
	private String brand;
	private double price;
	private float milege;
	
	Vehicle(int reg_no,String brand,double price,float milege)
	{
		this.reg_no=reg_no;
		this.brand=brand;
		this.price=price;
		this.milege=milege;
	}
	
	void display()
	{
		System.out.println("Reg No is "+reg_no);
		System.out.println("Brand is "+brand);
		System.out.println("Price is "+price);
		System.out.println("Milege is "+milege);
	}

	public static void main(String[] args) 
	{
		Vehicle v1=new Vehicle(100,"Maruti",60000,30);
		Vehicle v2=new Vehicle(101,"Honda",70000,40);
		if(v1.milege>v2.milege)
			System.out.println("Vehicle1 has high milege");
		else
			System.out.println("Vehicle2 has high milege");
		if(v1.price>v2.price)
			System.out.println("Vehicle1 has high Price");
		else
			System.out.println("Vehicle2 has high Price");
		
	}

}