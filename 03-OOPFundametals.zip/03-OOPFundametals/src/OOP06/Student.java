package OOP06;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class Student {

	int studentId;
	String name;
	String contactNumber;
	String course;
	double coursePrice;
	
	public Student(int studentId, String name, String contactNumber, String course, double coursePrice)  {
		
		this.studentId = studentId;
		this.name = name;
		this.contactNumber = contactNumber;
		this.course = course;
		this.coursePrice = coursePrice;
	}
	
	public void display()
	{
		System.out.println("Student id :"+studentId);
		System.out.println("Student name :"+ name);
		System.out.println("Student contact number :"+ contactNumber);
		System.out.println("Course :"+course);
		System.out.println("Course price :"+coursePrice);
	}
	
	public double getCourseFees()
	{
		return coursePrice;
	}
	
	
	
	public static void main(String[] args) {
		Student s1 = new Student(01,"Renuka","Java","9876543210",10000);
		Student s2 = new Student(02,"palash","AWS","9876543210",13000);
		Student s3 = new Student(03,"Omkar","C#","9876543210",10200);
		Student s4 = new Student(04,"mayur","DevOps","9876543210",19000);
		Student s5 = new Student(05,"komal","AWS","9876543210",13000);
		
		List<Student> stdlist = new ArrayList<Student>();
		stdlist.add(s1);
		stdlist.add(s2);
		stdlist.add(s3);
		stdlist.add(s4);
		stdlist.add(s5);
		
		

		stdlist.forEach(s -> s.display());
		
	}
	
}