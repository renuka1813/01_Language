package OOP03;

public class AccountApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Account acc=null;
		Saving saving = new Saving(101010,"Renuka",50000,4.5);
		Current current = new Current(110011,"Omkar",25000,50000);	}

}
