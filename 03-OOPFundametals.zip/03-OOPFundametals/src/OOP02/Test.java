package OOP02;
class A{
	public void print() {
		System.out.println("Class A");
	}
	public void print2() {
		System.out.println("Class A");
	}
	public A print3() {
		System.out.println("Class A");
		return null;
	}
	public Object print4() {
		System.out.println("Class A");
		return null;
	}
}
class B extends A{
	public void print() {
		System.out.println("Class B");
	}
	public void print2() {
		System.out.println("Class B");
	}
	public B print3() {
		System.out.println("Class A");
		return null;
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B obj = new B();
		obj.print();
	}

}
