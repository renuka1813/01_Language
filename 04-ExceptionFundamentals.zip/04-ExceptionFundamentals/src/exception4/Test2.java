package exception4;

public class Test2 {
	public static void checkEmail(String email) throws InvalidEmailException{
		boolean result= email.matches("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$");
		if(!result) {
			InvalidEmailException e = new InvalidEmailException("Invaild email exception");
			throw e;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String email = "krenuka9812@gmail.com";
		//String email = "krenuka9812gmail.com";
		try {
			checkEmail(email);
			System.out.println("Valid email:" +email);
		}
			catch(InvalidEmailException e) {
				System.out.println(e.getMessage());
			}

	}

}
