package exception4;

public class Test {
	//pass,email,mobile,full name,pancard
	public static void checkName(String name) throws InvalidNameException{
		boolean result=name.matches("[A-Z][a-z]+");
		if(!result) {
			InvalidNameException e = new InvalidNameException("Invaild name exception");
			throw e;
		}
	}
	public static void main(String[] args) {
		String name = "Renuka";
		try {
			checkName(name);
			System.out.println("Valid Name:" +name);
		}
			catch(InvalidNameException e) {
				System.out.println(e.getMessage());
			}
	}

}
