package exception4;

public class InvalidNumberException extends Exception {
	public InvalidNumberException(String message) {
		super(message);
	}
}
