package exception4;

public class Test3{
	public static void checkPhonenumber(String num) throws InvalidNumberException{
		boolean result= num.matches("(0/91)?[7-9][0-9]{9}");
		if(!result) {
			InvalidNumberException e = new InvalidNumberException("Invaild Phone number exception");
			throw e;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String num = "9999888";
		//String email = "krenuka9812gmail.com";
		try {
			checkPhonenumber(num);
			System.out.println("Valid number:" +num);
		}
			catch(InvalidNumberException e) {
				System.out.println(e.getMessage());
			}

	}

}
 