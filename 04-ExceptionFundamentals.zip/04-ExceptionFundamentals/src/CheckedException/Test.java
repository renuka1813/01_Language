package CheckedException;

import java.io.IOException;

public class Test {
	
	public static void meth() throws IOException{
		System.out.println("Start of method");
		boolean flag = false;
		if(flag)
			throw new IOException();
	}
	
	public static void main(String[] args) {
		try {
			Test.meth();
		}catch(IOException e) {
			System.out.println("IO POinter");
		}
		System.out.println("End of program.");
	}
}