package exception5;

public class Hockey3 {
	public static void main(String[] args) {
		System.out.println(5);
		try {
			System.out.println(1);
			throw new ClassCastException();
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(2);
			throw e;
		} catch (RuntimeException e) {
			System.out.println(3);
			throw e;
		} finally {
			System.out.println(4);
		}
		
		
	}
}
