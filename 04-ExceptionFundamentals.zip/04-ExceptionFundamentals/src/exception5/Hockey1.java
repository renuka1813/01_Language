package exception5;

public class Hockey1 {
	public static void main(String[] args) {
		int score = 1;
		try {
			
			System.out.println(score++);
		} catch (Exception e) {
			System.out.println(score++);
		} finally {
			System.out.println(score++);
		}
		System.out.println(score++);
	}
}
