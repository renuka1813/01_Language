package exception5;

class Derived extends Base {
}
class Base extends Exception {
}

public class Main {
	public static void main(String args[]) {
		try {
			throw new Derived();
		}catch (Derived d) {
			System.out.println("Derived");
		} 
		catch (Base b) {
			System.out.println("Base");
		} 
	}
}