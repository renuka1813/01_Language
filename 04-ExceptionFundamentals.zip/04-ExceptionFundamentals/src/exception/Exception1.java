package exception;

public class Exception1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number1, number2,result;
		
	}

}
