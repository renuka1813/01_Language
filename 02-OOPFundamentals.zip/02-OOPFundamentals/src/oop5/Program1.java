package oop5;

import java.util.Scanner;

public class Program1 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number");
		int number=sc.nextInt();
		
		System.out.println(findQube(number));

	}

	static int findQube(int a)
	{
		int digit;
		int result = 0;
		while(a!=0)
		{
			digit=a%10;
			result= (result+(int)Math.pow(digit,3));
			a=a/10;
			
			}
		
		return result;
	}
}
