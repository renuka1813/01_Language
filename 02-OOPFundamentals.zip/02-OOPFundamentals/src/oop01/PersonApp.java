package oop01;

public class PersonApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person obj1 = new Person();
		obj1.getData("Renuka","katneshwarkar","Pune");
		
		Person obj2 = new Person();
		obj2.getData("Renuka","Katneshwarkar","Pune");
	    
		obj1.show();
		obj2.show();
	}

}
