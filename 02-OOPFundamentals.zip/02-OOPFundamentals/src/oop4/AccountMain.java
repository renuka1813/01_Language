package oop4;
class Account{
	private String accountNumber;
	private String holderName;
	private double balance;
	public Account(String accountNumber, String holderName, double balance) {
		this.accountNumber = accountNumber;
		this.holderName = holderName;
		this.balance = balance;	
	}
	public void getAccountDetails(){
		System.out.println("accountNumber is "+accountNumber);
		System.out.println("holderName is "+holderName);
		System.out.println("balance is "+balance);
	}
	
}

class Saving extends Account{
	
	public Saving(String accountNumber, String holderName, double balance) {
		super(accountNumber, holderName, balance);
		System.out.println("This accounts rate of interest is "+ rateOfInterest);
		
	}
	final static private double rateOfInterest = 9.2;

	
}
class Current extends  Account{
	public Current(String accountNumber, String holderName, double balance) {
		super(accountNumber, holderName, balance);
		System.out.println("Overdraft for this account "+overdraft);
		
	}
	final static private double overdraft = 300000;

}

public class AccountMain{

	public static void main(String[] args) {
		
		Account obj1 = new Current("998877665544", "Ram", 98777.9);
		obj1.getAccountDetails();
		
		Account obj2 = new Saving("998877665544", "Ram", 98777.9);
		obj1.getAccountDetails();
		
		
		
	}

}