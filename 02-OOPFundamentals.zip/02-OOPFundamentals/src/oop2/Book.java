package oop2;

public class Book {
    String bookName;
    String bookAuthor;
    double bookPrice;
	static double discount;
	static {
		System.out.println("static block");
		discount =10;
	}
	
	public Book() {
		System.err.println("default constructor");;
	}
	public Book(String name,String bookAuthor,double price)
	{
		this.bookName=name;
		this.bookAuthor=bookAuthor;
		bookPrice=price;
	}
	public void showBookDetails() {
		System.out.println("Book Name: " +bookName);
		System.out.println("Author Name:  "+bookAuthor);
		System.out.println("Book Price  "+bookPrice);
		System.out.println("Price after discount"+calculateDiscount());
	}
	public static void setDiscount(double discount) {
		Book.discount=discount;
		
	}
	public double calculateDiscount() {
		double actualPrice= bookPrice-((this.discount/100*bookPrice));
		return actualPrice;
	}
}
