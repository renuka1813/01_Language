package oop2;

public class BookApp {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book.setDiscount(10);
		
		Book bk = new Book("c","letsc",200) ;
		Book bk1 = new Book("c","letsc",200) ;
		
	
		bk.showBookDetails();
		bk1.showBookDetails();
				
		
	}

}
