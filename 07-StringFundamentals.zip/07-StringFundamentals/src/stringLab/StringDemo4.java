package stringLab;

public class StringDemo4 {
	public static void main(String[] args) {
		long start = System.currentTimeMillis();//returns current time in format of millisecond
		
		String str1 = new String("MorningStar");
		for(int i=1; i<=1000000; i++) {
			str1 = str1 + "Hello";//string is immutable so we are creating new object thats why it will give time
		}
		System.out.println(str1.substring(0, 14));
		
		long end = System.currentTimeMillis();
		System.out.println("Time taken: "+(end-start)/1000.0);
	}
}
