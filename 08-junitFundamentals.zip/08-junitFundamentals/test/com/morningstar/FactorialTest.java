package com.morningstar;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FactorialTest {
	Factorial fact = null;
	@Before
	public void setup() {
		fact=new Factorial();
	}
	@Test
	public void testFindFactShouldReturnFactorial() {
		int result = fact.findFact(5);
		assertEquals(120, result);
	}

}
