package com.morningstar;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PrimeNumberTest {

	PrimeNumber target = null;
	@Before
	public void setup() {
		target=new PrimeNumber();
	}
	@Test
	public void testCheckPrimeNumber() {
		boolean result = target.checkPrime(5);
		assertEquals(true, result);
	}

}
