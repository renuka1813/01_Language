package com.morningstar;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MonthTest {

	Month target = null;
	@Before
	public void setup() {
		target=new Month();
	}
	@Test
	public void testFindMonthShouldReturnMonth() {
		String result = target.findMonth(1);
		assertEquals("Jan", result);
		
		
	}

}
