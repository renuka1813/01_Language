package com.morningstar;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalculatorTest2 {
	Calculator target = null;
	@Before
	public void setup()
	{
		target = new Calculator();
	}
	
	@After
	public void teardown() {
		target =null;
	}
	
	@Test
	public void testAdditionShouldReturnSumOfTwoNumber() {
		Calculator target =new Calculator();
		int result=target.addition(1000, 2000);
		assertEquals(3000, result);//to check addition method working or not
		assertEquals(1200, target.addition(1000, 200));
		assertEquals(1200, target.addition(1100, 100));
		assertEquals(1200, target.addition(1200, 0));
		
	}
	@Test
	public void testSumShouldReturnSumOfAllNumbers() {
		Calculator target =new Calculator();
		int result=target.sum(10,10,10,10);
		assertEquals(40, result);
		assertEquals(100, target.sum(50,50));
		assertEquals(100, target.sum(25,25,25,25));
	}
	@Test(expected=IllegalArgumentException.class)
	public void testSumShouldThrowIllegalArgumentException() {
		Calculator target =new Calculator();
		target.sum(10);
	}
}

