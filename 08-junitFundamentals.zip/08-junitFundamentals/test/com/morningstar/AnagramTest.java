package com.morningstar;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AnagramTest {

	Anagram target = null;
	@Before
	public void setup() {
		target=new Anagram();
	}
	@Test
	public void testAreAnagram() {
		boolean result=target.areAnagram("Renu", "Praj");
		assertEquals(false, result);
	}

}
