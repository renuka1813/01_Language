package com.morningstar;
import static org.junit.Assert.*;  
import org.junit.Test;  
  
public class MaximumNumberTest {  
  
    @Test  
    public void testFindMax(){  
        assertEquals(4,MaximumNumber.findMaxNumber(new int[]{1,3,4,2}));  
        assertEquals(8,MaximumNumber.findMaxNumber(new int[]{4,6,1,8,3,5}));  
    }  
}
