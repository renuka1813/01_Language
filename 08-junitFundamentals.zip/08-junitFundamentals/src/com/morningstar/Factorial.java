package com.morningstar;

public class Factorial {
	static int findFact(int a) 
	{
		int ans =0;
		if(a==1)
			return 1;
		ans=a*findFact(a-1);
		return ans;	
	}

}
