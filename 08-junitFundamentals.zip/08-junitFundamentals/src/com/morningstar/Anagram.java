package com.morningstar;

import java.util.Arrays;

public class Anagram {
	public static boolean areAnagram(String str,String ptr)
		{
			char[] arr1=str.toCharArray();
			char[] arr2=ptr.toCharArray();
			Arrays.sort(arr1);
			Arrays.sort(arr2);
			if(arr1.length!=arr2.length)
				return false;
			else
			{
				
			for(int i=0;i<arr1.length-1;i++)
			{
				if(arr1[i]!=arr2[i])
					return false;
			}
			
				return true;
			
			}
			
		}
}

