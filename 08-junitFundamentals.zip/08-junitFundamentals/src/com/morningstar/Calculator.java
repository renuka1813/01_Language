package com.morningstar;

public class Calculator {
	public int addition(int number1, int number2) {
		return number1 + number2;
	}
	public int sum(int ... numbers) throws IllegalArgumentException
	{
		if( numbers.length <= 1)
			throw new IllegalArgumentException("Enter more than one numbers");
		int sum =0;
		for(int num: numbers)
		{
			sum += num;
		}
		return sum;
	}

}
