package com.morningstar;

public class Month {
	static String findMonth(int number)
		{
			switch(number)
			{
			case 1:
			{
				return "Jan";
			}
			
			case 2:
			{
				return "Feb";
			}
			
			case 3:
			{
				return "March";
			}
			case 4:
			{
				return "April";
			}
			case 5:
			{
				return "May";
			}
			case 6:
			{
				return "June";
			}
			
			case 7:
			{
				return "July";
			}
			
			case 8:
			{
				return "August";
			}
			case 9:
			{
				return "Sept";
			}
			case 10:
			{
				return "Octo";
			}
			case 11:
			{
				return "November";
			}
			case 12:
			{
				return "December";
			}
			
			default:
				return "Invalid";
			}
		}
	
}

