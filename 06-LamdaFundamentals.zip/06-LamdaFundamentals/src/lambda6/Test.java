package lambda6;

import java.util.ArrayList;
import java.util.List;

import lambda4.Student;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student(100, "Renuka", 80);
		Student student2 = new Student(101, "Omkar", 90);
		Student student3 = new Student(102, "komal", 98);
		Student student4 = new Student(103, "palash", 89);
		
		List<Student> list = new ArrayList<>();
		list.add(student1);
		list.add(student2);
		list.add(student3);
		list.add(student4);
		
//		list.stream().forEach(element -> System.out.println(element.getStudentName()));
//		list.stream().forEach(element -> System.out.println(element.getStudentScore()));
//		list.stream().forEach(element -> System.out.println(element.getStudentId()));
		
		double max= list.stream().mapToDouble(element -> element.getStudentScore() ).max().getAsDouble();
		System.out.println("Max Score: "+max);
		
	}

}
