package lambda4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

public class ArrayListDemo {
	public static void printAll(List<Student> list)
	{
		for(Student student : list ) {
			System.out.println(student);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student(100, "Renuka", 80);
		Student student2 = new Student(101, "Omkar", 90);
		Student student3 = new Student(102, "komal", 98);
		Student student4 = new Student(103, "palash", 89);
		
		
		System.out.println("student1 hashcode: "+student1.hashCode());
		System.out.println("student1 hashcode: "+student2.hashCode());
		
		
		List<Student> list = new ArrayList<>(); // diamond -- java 1.7
		list.add(student1);
		list.add(student2);
		list.add(student3);
		
		printAll(list);
		System.out.println("-----------------");
	//	Collections.sort(list , new StudentScoreSorter());
		Comparator<Student> comparator = (Student s1, Student s2) ->
		{
			if(s1.getStudentScore() > s2.getStudentScore())
					return 1;
			else
				return -1;
		};
		Collections.sort(list, comparator);
		printAll(list);
		
		System.out.println("-----------------");
		Comparator<Student> comparator2 = (s1, s2) -> (s1. getStudentName().compareTo(s2.getStudentName()));
		Collections.sort(list , comparator2);
		printAll(list);

	}

}
