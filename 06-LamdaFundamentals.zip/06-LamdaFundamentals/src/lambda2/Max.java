package lambda2;

@FunctionalInterface
public interface Max {
	public int max(int n1, int n2);

}
