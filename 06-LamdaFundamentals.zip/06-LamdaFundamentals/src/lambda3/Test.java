package lambda3;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Test {
	public static void main(String[] args) {
		
		
	}

}
