package lambda1;
@FunctionalInterface
interface I1{
	void meth1();
	default void meth2() {
		System.out.println("default method ..");
	}
	static void meth3() {
		System.out.println("sttatic method ..");
	}
}
class C1 implements I1{
	@Override
	public void meth1() {
		System.out.println("meth1 from class c1");
	}
}
public class Test {
	public static void main(String[] args) {
		I1 obj = new C1();
		obj.meth1();
		
		I1 obj2 = new I1() {
			@Override
			public void meth1() {
				System.out.println("meth1 from annonums inner class");
			}
		};
		obj2.meth1();
		
		I1 obj3 = () -> System.out.println("meth from lambda expression");
	    obj3.meth1();
	}

}
