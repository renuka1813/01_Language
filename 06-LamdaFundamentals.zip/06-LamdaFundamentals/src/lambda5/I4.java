package lambda5;

public interface I4 {
	public void xyz();
	
}
