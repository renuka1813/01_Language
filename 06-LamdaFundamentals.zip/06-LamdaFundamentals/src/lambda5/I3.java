package lambda5;

@FunctionalInterface
public interface I3 {
	public boolean express(String username, String password);

}
