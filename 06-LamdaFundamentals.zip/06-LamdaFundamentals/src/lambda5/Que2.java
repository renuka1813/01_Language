//Write a method that uses lambda expression to format a given string, where a space is
//inserted between each character of string. For ex., if input is �TEST�, then expected output is
//�T E S T�.

package lambda5;

public class Que2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I2 ref2 =(str) -> {
			StringBuilder sb=new StringBuilder();
			for(int i = 0; i<str.length(); i++) 
			{
				sb.append(str.charAt(i));
				sb.append(" ");
			}
			return sb.toString();		
		};
		System.out.println("Output: "+ref2.expression("TEST"));

	}

}
