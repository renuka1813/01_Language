package lambda5;

public interface I1 {
	public int multiple(int x1, int y1);

}
