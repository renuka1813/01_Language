//Write a method to calculate factorial of a number. Test this method using method reference
//feature.

package lambda5;

public class Que4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
