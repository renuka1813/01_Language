//1. Write a lambda expression which accepts x and y numbers and return xy
package lambda5;


public class Que1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		I1  ref1 =(x1, y1) -> {
			int total=1;
			for(int i=0;i<y1; i++) {
				total = total*x1;
			}
			return total;
		};
		System.out.println("Y times x: "+ref1.multiple(4,4));

	}

}
