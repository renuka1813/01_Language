//Write a method that uses lambda expression to accept username and password and return
//true or false. (Note: Use any custom values for username and password for authentication)

package lambda5;

public class Que3 {
//	public static boolean validate(String username , String password) {
//		I3 ref3 =(username , password) -> {
//			
//			String str = "Renuka";
//			String str1 ="renuka@123";
//			
//			if(str.equals(username) && str1.equals(password))
//				return true;
//			else
//				return false;
//		};
//		
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I3 ref3 =(username , password) -> {
			
			String str = "Renuka";
			String str1 ="renuka@123";
			
			if(str.equals(username) && str1.equals(password))
				return true;
			else
				return false;
		};
		System.out.println("success Output: "+ref3.express("renuka", "renuka@123"));
	}

}
