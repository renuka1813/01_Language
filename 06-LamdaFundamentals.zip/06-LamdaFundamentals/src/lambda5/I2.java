package lambda5;

public interface I2 {
	public String expression(String str);

}
